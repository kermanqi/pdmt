function[global_displacement_vector]=function_displacement_solution(dimension,size_particle,global_stiffness_matrix,size_displacement_boundary_left,particle_boundary_left, ...
         size_displacement_boundary_right,particle_boundary_right,size_displacement_boundary_bottom,particle_boundary_bottom,size_displacement_boundary_top, ...
         particle_boundary_top,size_displacement_boundary_behind,particle_boundary_behind,size_displacement_boundary_front,particle_boundary_front, ...
         size_uniform_load_left,particle_uniform_load_left,size_uniform_load_right,particle_uniform_load_right,size_uniform_load_bottom,particle_uniform_load_bottom, ...
         size_uniform_load_top,particle_uniform_load_top,size_uniform_load_behind,particle_uniform_load_behind,size_uniform_load_front,particle_uniform_load_front, ...
         displacement_left,displacement_right,displacement_bottom,displacement_top,displacement_behind,displacement_front,uniform_load_left,uniform_load_right, ...
         uniform_load_bottom,uniform_load_top,uniform_load_behind,uniform_load_front,det_displacement_left,det_displacement_right,det_displacement_bottom, ...
         det_displacement_top,det_displacement_behind,det_displacement_front,det_uniform_load_left,det_uniform_load_right,det_uniform_load_bottom, ...
         det_uniform_load_top,det_uniform_load_behind,det_uniform_load_front,body_force,boundary_condition_left,boundary_condition_right,boundary_condition_bottom, ...
         boundary_condition_top,boundary_condition_behind,boundary_condition_front,volume_particle,itime,output_interval)

global_load_vector=zeros(size_particle*dimension,1); % ���������������ֵ
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%һά���
if dimension==1
%%%%%%%%%%%%%%%%%%%%%%%
%ʩ��λ�Ʊ߽�����
    % ��߽�
    if boundary_condition_left(1)==1                                % �����߽綨����λ�Ʊ߽���������ִ����������е�����
        for i=1:size_displacement_boundary_left                     % ����߽�ʩ��λ�Ʊ߽���������������ѭ��
            ii=particle_boundary_left(i);                           % ii��ʾ��߽�ʩ��λ�Ʊ߽����������ӱ��
            global_stiffness_matrix(ii,ii)=global_stiffness_matrix(ii,ii)*1.0e8;    % ���ó˴�����������նȾ�����в���
            global_load_vector(ii,1)=global_stiffness_matrix(ii,ii)*displacement_left(1);    % ���ó˴���������������������в���
        end
    end
    % �ұ߽�
    if boundary_condition_right(1)==1                           % ����ұ߽綨����λ�Ʊ߽���������ִ����������е�����
        for i=1:size_displacement_boundary_right                % ���ұ߽�ʩ��λ�Ʊ߽���������������ѭ��
            ii=particle_boundary_right(i);                      % ii��ʾ�ұ߽�ʩ��λ�Ʊ߽����������ӱ��
            global_stiffness_matrix(ii,ii)=global_stiffness_matrix(ii,ii)*1.0e8;    % ���ó˴�����������նȾ�����в���
            global_load_vector(ii,1)=global_stiffness_matrix(ii,ii)*displacement_right(1); % ���ó˴���������������������в���
        end
    end
%%%%%%%%%%%%%%%%%%%%%%%
%ʩ�Ӿ�����������
    % ��߽�
    if boundary_condition_left(1)==2    % �����߽綨���˺�����������ִ����������е�����
        for i=1:size_uniform_load_left  % ����߽�ʩ�Ӻ�����������������ѭ��
            ii=particle_uniform_load_left(i);   % ii��ʾ��߽�ʩ�Ӻ������������ӱ��
            global_load_vector(ii,1)=global_load_vector(ii,1)+uniform_load_left(1)*volume_particle; % ���������������Ӧλ�����Ӻ���
        end
    end
    % �ұ߽�
    if boundary_condition_right(1)==2    % ����ұ߽綨���˺�����������ִ����������е�����
        for i=1:size_uniform_load_right  % ���ұ߽�ʩ�Ӻ�����������������ѭ��
            ii=particle_uniform_load_right(i);   % ii��ʾ�ұ߽�ʩ�Ӻ������������ӱ��
            global_load_vector(ii,1)=global_load_vector(ii,1)+uniform_load_right(1)*volume_particle; % ���������������Ӧλ�����Ӻ���
        end
    end
%%%%%%%%%%%%%%%%%%%%%%%
%ʩ������
    if body_force(1)~=0    % ���x���������ܶȲ�Ϊ0��˵��ʩ����x������������أ���ִ����������е�����
        for i=1:size_particle % ����������ѭ��
            global_load_vector(ii,1)=global_load_vector(ii,1)+body_force(1)*volume_particle; % ���������������Ӧλ�����Ӻ���
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%��ά���
if dimension==2
%%%%%%%%%%%%%%%%%%%%%%%
%ʩ��λ�Ʊ߽�����
    % ��߽�
    if boundary_condition_left(1)==1
        for i=1:size_displacement_boundary_left
            ii=particle_boundary_left(i);
            global_stiffness_matrix(ii*2-1,ii*2-1)=global_stiffness_matrix(ii*2-1,ii*2-1)*1.0e8;
            global_load_vector(ii*2-1,1)=global_stiffness_matrix(ii*2-1,ii*2-1)*(displacement_left(1)+(itime-1)*det_displacement_left(1));
        end
    end
    if boundary_condition_left(2)==1
        for i=1:size_displacement_boundary_left
            ii=particle_boundary_left(i);
            global_stiffness_matrix(ii*2,ii*2)=global_stiffness_matrix(ii*2,ii*2)*1.0e8;
            global_load_vector(ii*2,1)=global_stiffness_matrix(ii*2,ii*2)*(displacement_left(2)+(itime-1)*det_displacement_left(2));
        end
    end
    % �ұ߽�
    if boundary_condition_right(1)==1
        for i=1:size_displacement_boundary_right
            ii=particle_boundary_right(i);
            global_stiffness_matrix(ii*2-1,ii*2-1)=global_stiffness_matrix(ii*2-1,ii*2-1)*1.0e8;
            global_load_vector(ii*2-1,1)=global_stiffness_matrix(ii*2-1,ii*2-1)*(displacement_right(1)+(itime-1)*det_displacement_right(1));
        end
    end
    if boundary_condition_right(2)==1
        for i=1:size_displacement_boundary_right
            ii=particle_boundary_right(i);
            global_stiffness_matrix(ii*2,ii*2)=global_stiffness_matrix(ii*2,ii*2)*1.0e8;
            global_load_vector(ii*2,1)=global_stiffness_matrix(ii*2,ii*2)*(displacement_right(2)+(itime-1)*det_displacement_right(2));
        end
    end
    % �±߽�
    if boundary_condition_bottom(1)==1
        for i=1:size_displacement_boundary_bottom
            ii=particle_boundary_bottom(i);
            global_stiffness_matrix(ii*2-1,ii*2-1)=global_stiffness_matrix(ii*2-1,ii*2-1)*1.0e8;
            global_load_vector(ii*2-1,1)=global_stiffness_matrix(ii*2-1,ii*2-1)*(displacement_bottom(1)+(itime-1)*det_displacement_bottom(1));
        end
    end
    if boundary_condition_bottom(2)==1
        for i=1:size_displacement_boundary_bottom
            ii=particle_boundary_bottom(i);
            global_stiffness_matrix(ii*2,ii*2)=global_stiffness_matrix(ii*2,ii*2)*1.0e8;
            global_load_vector(ii*2,1)=global_stiffness_matrix(ii*2,ii*2)*(displacement_bottom(2)+(itime-1)*det_displacement_bottom(2));
        end
    end
    % �ϱ߽�
    if boundary_condition_top(1)==1
        for i=1:size_displacement_boundary_top
            ii=particle_boundary_top(i);
            global_stiffness_matrix(ii*2-1,ii*2-1)=global_stiffness_matrix(ii*2-1,ii*2-1)*1.0e8;
            global_load_vector(ii*2-1,1)=global_stiffness_matrix(ii*2-1,ii*2-1)*(displacement_top(1)+(itime-1)*det_displacement_top(1));
        end
    end
    if boundary_condition_top(2)==1
        for i=1:size_displacement_boundary_top
            ii=particle_boundary_top(i);
            global_stiffness_matrix(ii*2,ii*2)=global_stiffness_matrix(ii*2,ii*2)*1.0e8;
            global_load_vector(ii*2,1)=global_stiffness_matrix(ii*2,ii*2)*(displacement_top(2)+(itime-1)*det_displacement_top(2));
        end
    end
%%%%%%%%%%%%%%%%%%%%%%%
%ʩ�Ӿ�����������
    % ��߽�
    if boundary_condition_left(1)==2
        for i=1:size_uniform_load_left
            ii=particle_uniform_load_left(i);
            global_load_vector(ii*2-1,1)=global_load_vector(ii*2-1,1)+(uniform_load_left(1)+(itime-1)*det_uniform_load_left(1))*volume_particle;
        end
    end
    if boundary_condition_left(2)==2
        for i=1:size_uniform_load_left
            ii=particle_uniform_load_left(i);
            global_load_vector(ii*2,1)=global_load_vector(ii*2,1)+(uniform_load_left(2)+(itime-1)*det_uniform_load_left(2))*volume_particle;
        end
    end
    % �ұ߽�
    if boundary_condition_right(1)==2
        for i=1:size_uniform_load_right
            ii=particle_uniform_load_right(i);
            global_load_vector(ii*2-1,1)=global_load_vector(ii*2-1,1)+(uniform_load_right(1)+(itime-1)*det_uniform_load_right(1))*volume_particle;
        end
    end
    if boundary_condition_right(2)==2
        for i=1:size_uniform_load_right
            ii=particle_uniform_load_right(i);
            global_load_vector(ii*2,1)=global_load_vector(ii*2,1)+(uniform_load_right(2)+(itime-1)*det_uniform_load_right(2))*volume_particle;
        end
    end
    % �±߽�
    if boundary_condition_bottom(1)==2
        for i=1:size_uniform_load_bottom
            ii=particle_uniform_load_bottom(i);
            global_load_vector(ii*2-1,1)=global_load_vector(ii*2-1,1)+(uniform_load_bottom(1)+(itime-1)*det_uniform_load_bottom(1))*volume_particle;
        end
    end
    if boundary_condition_bottom(2)==2
        for i=1:size_uniform_load_bottom
            ii=particle_uniform_load_bottom(i);
            global_load_vector(ii*2,1)=global_load_vector(ii*2,1)+(uniform_load_bottom(2)+(itime-1)*det_uniform_load_bottom(2))*volume_particle;
        end
    end
    % �ϱ߽�
    if boundary_condition_top(1)==2
        for i=1:size_uniform_load_top
            ii=particle_uniform_load_top(i);
            global_load_vector(ii*2-1,1)=global_load_vector(ii*2-1,1)+(uniform_load_top(1)+(itime-1)*det_uniform_load_top(1))*volume_particle;
        end
    end
    if boundary_condition_top(2)==2
        for i=1:size_uniform_load_top
            ii=particle_uniform_load_top(i);
            global_load_vector(ii*2,1)=global_load_vector(ii*2,1)+(uniform_load_top(2)+(itime-1)*det_uniform_load_top(2))*volume_particle;
        end
    end
%%%%%%%%%%%%%%%%%%%%%%%
%ʩ������
    if body_force(1)~=0
        for i=1:size_particle
            global_load_vector(ii*2-1,1)=global_load_vector(ii*2-1,1)+body_force(1)*volume_particle;
        end
    end
    if body_force(2)~=0
        for i=1:size_particle
            global_load_vector(ii*2,1)=global_load_vector(ii*2,1)+body_force(2)*volume_particle;
        end
    end
%%%%%%%%%%%%%%%%%%%%%%%

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%��ά���
if dimension==3
%%%%%%%%%%%%%%%%%%%%%%%
%ʩ��λ�Ʊ߽�����
    % ��߽�
    if boundary_condition_left(1)==1
        for i=1:size_displacement_boundary_left
            ii=particle_boundary_left(i);
            global_stiffness_matrix(ii*3-2,ii*3-2)=global_stiffness_matrix(ii*3-2,ii*3-2)*1.0e8;
            global_load_vector(ii*3-2,1)=global_stiffness_matrix(ii*3-2,ii*3-2)*(displacement_left(1)+(itime-1)*det_displacement_left(1));
        end
    end
    if boundary_condition_left(2)==1
        for i=1:size_displacement_boundary_left
            ii=particle_boundary_left(i);
            global_stiffness_matrix(ii*3-1,ii*3-1)=global_stiffness_matrix(ii*3-1,ii*3-1)*1.0e8;
            global_load_vector(ii*3-1,1)=global_stiffness_matrix(ii*3-1,ii*3-1)*(displacement_left(2)+(itime-1)*det_displacement_left(2));
        end
    end
    if boundary_condition_left(3)==1
        for i=1:size_displacement_boundary_left
            ii=particle_boundary_left(i);
            global_stiffness_matrix(ii*3,ii*3)=global_stiffness_matrix(ii*3,ii*3)*1.0e8;
            global_load_vector(ii*3,1)=global_stiffness_matrix(ii*3,ii*3)*(displacement_left(3)+(itime-1)*det_displacement_left(3));
        end
    end
    % �ұ߽�
    if boundary_condition_right(1)==1
        for i=1:size_displacement_boundary_right
            ii=particle_boundary_right(i);
            global_stiffness_matrix(ii*3-2,ii*3-2)=global_stiffness_matrix(ii*3-2,ii*3-2)*1.0e8;
            global_load_vector(ii*3-2,1)=global_stiffness_matrix(ii*3-2,ii*3-2)*(displacement_right(1)+(itime-1)*det_displacement_right(1));
        end
    end
    if boundary_condition_right(2)==1
        for i=1:size_displacement_boundary_right
            ii=particle_boundary_right(i);
            global_stiffness_matrix(ii*3-1,ii*3-1)=global_stiffness_matrix(ii*3-1,ii*3-1)*1.0e8;
            global_load_vector(ii*3-1,1)=global_stiffness_matrix(ii*3-1,ii*3-1)*(displacement_right(2)+(itime-1)*det_displacement_right(2));
        end
    end
    if boundary_condition_right(3)==1
        for i=1:size_displacement_boundary_right
            ii=particle_boundary_right(i);
            global_stiffness_matrix(ii*3,ii*3)=global_stiffness_matrix(ii*3,ii*3)*1.0e8;
            global_load_vector(ii*3,1)=global_stiffness_matrix(ii*3,ii*3)*(displacement_right(3)+(itime-1)*det_displacement_right(3));
        end
    end
    % �±߽�
    if boundary_condition_bottom(1)==1
        for i=1:size_displacement_boundary_bottom
            ii=particle_boundary_bottom(i);
            global_stiffness_matrix(ii*3-2,ii*3-2)=global_stiffness_matrix(ii*3-2,ii*3-2)*1.0e8;
            global_load_vector(ii*3-2,1)=global_stiffness_matrix(ii*3-2,ii*3-2)*(displacement_bottom(1)+(itime-1)*det_displacement_bottom(1));
        end
    end
    if boundary_condition_bottom(2)==1
        for i=1:size_displacement_boundary_bottom
            ii=particle_boundary_bottom(i);
            global_stiffness_matrix(ii*3-1,ii*3-1)=global_stiffness_matrix(ii*3-1,ii*3-1)*1.0e8;
            global_load_vector(ii*3-1,1)=global_stiffness_matrix(ii*3-1,ii*3-1)*(displacement_bottom(2)+(itime-1)*det_displacement_bottom(2));
        end
    end
    if boundary_condition_bottom(3)==1
        for i=1:size_displacement_boundary_bottom
            ii=particle_boundary_bottom(i);
            global_stiffness_matrix(ii*3,ii*3)=global_stiffness_matrix(ii*3,ii*3)*1.0e8;
            global_load_vector(ii*3,1)=global_stiffness_matrix(ii*3,ii*3)*(displacement_bottom(3)+(itime-1)*det_displacement_bottom(3));
        end
    end
    % �ϱ߽�
    if boundary_condition_top(1)==1
        for i=1:size_displacement_boundary_top
            ii=particle_boundary_top(i);
            global_stiffness_matrix(ii*3-2,ii*3-2)=global_stiffness_matrix(ii*3-2,ii*3-2)*1.0e8;
            global_load_vector(ii*3-2,1)=global_stiffness_matrix(ii*3-2,ii*3-2)*(displacement_top(1)+(itime-1)*det_displacement_top(1));
        end
    end
    if boundary_condition_top(2)==1
        for i=1:size_displacement_boundary_top
            ii=particle_boundary_top(i);
            global_stiffness_matrix(ii*3-1,ii*3-1)=global_stiffness_matrix(ii*3-1,ii*3-1)*1.0e8;
            global_load_vector(ii*3-1,1)=global_stiffness_matrix(ii*3-1,ii*3-1)*(displacement_top(2)+(itime-1)*det_displacement_top(2));
        end
    end
    if boundary_condition_top(3)==1
        for i=1:size_displacement_boundary_top
            ii=particle_boundary_top(i);
            global_stiffness_matrix(ii*3,ii*3)=global_stiffness_matrix(ii*3,ii*3)*1.0e8;
            global_load_vector(ii*3,1)=global_stiffness_matrix(ii*3,ii*3)*(displacement_top(3)+(itime-1)*det_displacement_top(3));
        end
    end
    % ��߽�
    if boundary_condition_behind(1)==1
        for i=1:size_displacement_boundary_behind
            ii=particle_boundary_behind(i);
            global_stiffness_matrix(ii*3-2,ii*3-2)=global_stiffness_matrix(ii*3-2,ii*3-2)*1.0e8;
            global_load_vector(ii*3-2,1)=global_stiffness_matrix(ii*3-2,ii*3-2)*(displacement_behind(1)+(itime-1)*det_displacement_behind(1));
        end
    end
    if boundary_condition_behind(2)==1
        for i=1:size_displacement_boundary_behind
            ii=particle_boundary_behind(i);
            global_stiffness_matrix(ii*3-1,ii*3-1)=global_stiffness_matrix(ii*3-1,ii*3-1)*1.0e8;
            global_load_vector(ii*3-1,1)=global_stiffness_matrix(ii*3-1,ii*3-1)*(displacement_behind(2)+(itime-1)*det_displacement_behind(2));
        end
    end
    if boundary_condition_behind(3)==1
        for i=1:size_displacement_boundary_behind
            ii=particle_boundary_behind(i);
            global_stiffness_matrix(ii*3,ii*3)=global_stiffness_matrix(ii*3,ii*3)*1.0e8;
            global_load_vector(ii*3,1)=global_stiffness_matrix(ii*3,ii*3)*(displacement_behind(3)+(itime-1)*det_displacement_behind(3));
        end
    end
    % ǰ�߽�
    if boundary_condition_front(1)==1
        for i=1:size_displacement_boundary_front
            ii=particle_boundary_front(i);
            global_stiffness_matrix(ii*3-2,ii*3-2)=global_stiffness_matrix(ii*3-2,ii*3-2)*1.0e8;
            global_load_vector(ii*3-2,1)=global_stiffness_matrix(ii*3-2,ii*3-2)*(displacement_front(1)+(itime-1)*det_displacement_front(1));
        end
    end
    if boundary_condition_front(2)==1
        for i=1:size_displacement_boundary_front
            ii=particle_boundary_front(i);
            global_stiffness_matrix(ii*3-1,ii*3-1)=global_stiffness_matrix(ii*3-1,ii*3-1)*1.0e8;
            global_load_vector(ii*3-1,1)=global_stiffness_matrix(ii*3-1,ii*3-1)*(displacement_front(2)+(itime-1)*det_displacement_front(2));
        end
    end
    if boundary_condition_front(3)==1
        for i=1:size_displacement_boundary_front
            ii=particle_boundary_front(i);
            global_stiffness_matrix(ii*3,ii*3)=global_stiffness_matrix(ii*3,ii*3)*1.0e8;
            global_load_vector(ii*3,1)=global_stiffness_matrix(ii*3,ii*3)*(displacement_front(3)+(itime-1)*det_displacement_front(3));
        end
    end
%%%%%%%%%%%%%%%%%%%%%%%
%ʩ�Ӿ�����������
    % ��߽�
    if boundary_condition_left(1)==2
        for i=1:size_uniform_load_left
            ii=particle_uniform_load_left(i);
            global_load_vector(ii*3-2,1)=global_load_vector(ii*3-2,1)+(uniform_load_left(1)+(itime-1)*det_uniform_load_left(1))*volume_particle;
        end
    end
    if boundary_condition_left(2)==2
        for i=1:size_uniform_load_left
            ii=particle_uniform_load_left(i);
            global_load_vector(ii*3-1,1)=global_load_vector(ii*3-1,1)+(uniform_load_left(2)+(itime-1)*det_uniform_load_left(2))*volume_particle;
        end
    end
    if boundary_condition_left(3)==2
        for i=1:size_uniform_load_left
            ii=particle_uniform_load_left(i);
            global_load_vector(ii*3,1)=global_load_vector(ii*3,1)+(uniform_load_left(3)+(itime-1)*det_uniform_load_left(3))*volume_particle;
        end
    end
    % �ұ߽�
    if boundary_condition_right(1)==2
        for i=1:size_uniform_load_right
            ii=particle_uniform_load_right(i);
            global_load_vector(ii*3-2,1)=global_load_vector(ii*3-2,1)+(uniform_load_right(1)+(itime-1)*det_uniform_load_right(1))*volume_particle;
        end
    end
    if boundary_condition_right(2)==2
        for i=1:size_uniform_load_right
            ii=particle_uniform_load_right(i);
            global_load_vector(ii*3-1,1)=global_load_vector(ii*3-1,1)+(uniform_load_right(2)+(itime-1)*det_uniform_load_right(2))*volume_particle;
        end
    end
    if boundary_condition_right(3)==2
        for i=1:size_uniform_load_right
            ii=particle_uniform_load_right(i);
            global_load_vector(ii*3,1)=global_load_vector(ii*3,1)+(uniform_load_right(3)+(itime-1)*det_uniform_load_right(3))*volume_particle;
        end
    end
    % �±߽�
    if boundary_condition_bottom(1)==2
        for i=1:size_uniform_load_bottom
            ii=particle_uniform_load_bottom(i);
            global_load_vector(ii*3-2,1)=global_load_vector(ii*3-2,1)+(uniform_load_bottom(1)+(itime-1)*det_uniform_load_bottom(1))*volume_particle;
        end
    end
    if boundary_condition_bottom(2)==2
        for i=1:size_uniform_load_bottom
            ii=particle_uniform_load_bottom(i);
            global_load_vector(ii*3-1,1)=global_load_vector(ii*3-1,1)+(uniform_load_bottom(2)+(itime-1)*det_uniform_load_bottom(2))*volume_particle;
        end
    end
    if boundary_condition_bottom(3)==2
        for i=1:size_uniform_load_bottom
            ii=particle_uniform_load_bottom(i);
            global_load_vector(ii*3,1)=global_load_vector(ii*3,1)+(uniform_load_bottom(3)+(itime-1)*det_uniform_load_bottom(3))*volume_particle;
        end
    end
    % �ϱ߽�
    if boundary_condition_top(1)==2
        for i=1:size_uniform_load_top
            ii=particle_uniform_load_top(i);
            global_load_vector(ii*3-2,1)=global_load_vector(ii*3-2,1)+(uniform_load_top(1)+(itime-1)*det_uniform_load_top(1))*volume_particle;
        end
    end
    if boundary_condition_top(2)==2
        for i=1:size_uniform_load_top
            ii=particle_uniform_load_top(i);
            global_load_vector(ii*3-1,1)=global_load_vector(ii*3-1,1)+(uniform_load_top(2)+(itime-1)*det_uniform_load_top(2))*volume_particle;
        end
    end
    if boundary_condition_top(3)==2
        for i=1:size_uniform_load_top
            ii=particle_uniform_load_top(i);
            global_load_vector(ii*3,1)=global_load_vector(ii*3,1)+(uniform_load_top(3)+(itime-1)*det_uniform_load_top(3))*volume_particle;
        end
    end
    % ��߽�
    if boundary_condition_behind(1)==2
        for i=1:size_uniform_load_behind
            ii=particle_uniform_load_behind(i);
            global_load_vector(ii*3-2,1)=global_load_vector(ii*3-2,1)+(uniform_load_behind(1)+(itime-1)*det_uniform_load_behind(1))*volume_particle;
        end
    end
    if boundary_condition_behind(2)==2
        for i=1:size_uniform_load_behind
            ii=particle_uniform_load_behind(i);
            global_load_vector(ii*3-1,1)=global_load_vector(ii*3-1,1)+(uniform_load_behind(2)+(itime-1)*det_uniform_load_behind(2))*volume_particle;
        end
    end
    if boundary_condition_behind(3)==2
        for i=1:size_uniform_load_behind
            ii=particle_uniform_load_behind(i);
            global_load_vector(ii*3,1)=global_load_vector(ii*3,1)+(uniform_load_behind(3)+(itime-1)*det_uniform_load_behind(3))*volume_particle;
        end
    end
    % ǰ�߽�
    if boundary_condition_front(1)==2
        for i=1:size_uniform_load_front
            ii=particle_uniform_load_front(i);
            global_load_vector(ii*3-2,1)=global_load_vector(ii*3-2,1)+(uniform_load_front(1)+(itime-1)*det_uniform_load_front(1))*volume_particle;
        end
    end
    if boundary_condition_front(2)==2
        for i=1:size_uniform_load_front
            ii=particle_uniform_load_front(i);
            global_load_vector(ii*3-1,1)=global_load_vector(ii*3-1,1)+(uniform_load_front(2)+(itime-1)*det_uniform_load_front(2))*volume_particle;
        end
    end
    if boundary_condition_front(3)==2
        for i=1:size_uniform_load_front
            ii=particle_uniform_load_front(i);
            global_load_vector(ii*3,1)=global_load_vector(ii*3,1)+(uniform_load_front(3)+(itime-1)*det_uniform_load_front(3))*volume_particle;
        end
    end
%%%%%%%%%%%%%%%%%%%%%%%
%ʩ������
    if body_force(1)~=0
        for i=1:size_particle
            global_load_vector(ii*3-2,1)=global_load_vector(ii*3-2,1)+body_force(1)*volume_particle;
        end
    end
    if body_force(2)~=0
        for i=1:size_particle
            global_load_vector(ii*3-1,1)=global_load_vector(ii*3-1,1)+body_force(2)*volume_particle;
        end
    end
    if body_force(3)~=0
        for i=1:size_particle
            global_load_vector(ii*3,1)=global_load_vector(ii*3,1)+body_force(3)*volume_particle;
        end
    end
%%%%%%%%%%%%%%%%%%%%%%%
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global_displacement_vector=global_stiffness_matrix\global_load_vector;  % �������λ�ƺ���
if mod(itime,output_interval)==0  % ���itime��output_intervalȡ����Ϊ0����ִ����������е�����
    str1='displacement_';           % ��������ļ������еĵ�1���� displacement_
    str2=num2str(itime);           % ��������ļ������еĵ�2���� itime
    str3='.txt';                    % ��������ļ������еĵ�3���� .txt�����ļ���չ��
    str4=strcat(str1,str2,str3);    % ���ļ�����д��һ�������У���displacement_itime.txt������itimeָ������㲽�������itime=1,������ļ���Ϊdisplacement_1.txt
    dlmwrite(str4,global_displacement_vector);  % ���� dlmwrite ������global_displacement_vectorд���ı��ļ�displacement_itime.txt
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%